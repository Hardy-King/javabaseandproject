package com.online.taxi.dto.map;

import lombok.Data;

/**
 */
@Data
public class Distance {

	private Double distance;

}
