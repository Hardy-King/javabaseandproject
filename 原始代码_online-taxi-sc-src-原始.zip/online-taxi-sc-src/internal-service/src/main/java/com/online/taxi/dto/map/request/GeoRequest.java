package com.online.taxi.dto.map.request;

import lombok.Data;

/**
 * @date 2018/9/14
 */
@Data
public class GeoRequest {
    private String longitude;
    private String latitude;
}
