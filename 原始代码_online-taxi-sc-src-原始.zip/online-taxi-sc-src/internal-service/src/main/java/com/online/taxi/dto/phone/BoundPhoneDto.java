package com.online.taxi.dto.phone;

import lombok.Data;

/**
 *绑定手机号
 * @date 2018/9/7
 */
@Data
public class BoundPhoneDto {
    private String axbSubsId;
    private String axbSecretNo;
}
