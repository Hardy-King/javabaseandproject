package com.online.taxi.dto.map;

import lombok.Data;

/**
 * 
 */
@Data
public class Location {
	
	private Long locateTime;
	
	private String longitude;
	
	private String latitude;
	
}