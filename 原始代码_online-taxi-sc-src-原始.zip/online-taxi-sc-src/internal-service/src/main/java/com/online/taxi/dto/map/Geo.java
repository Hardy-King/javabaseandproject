package com.online.taxi.dto.map;

import lombok.Data;

/**
 * @date 2018/9/14
 */
@Data
public class Geo {
    private String cityCode;

    private String formateedAddress;
}
