package com.online.taxi.dto.map;

import lombok.Data;
/**
 * 
 */
@Data
public class BaseResponse {
	
	private int errcode;
	
	private String errmsg;
}
