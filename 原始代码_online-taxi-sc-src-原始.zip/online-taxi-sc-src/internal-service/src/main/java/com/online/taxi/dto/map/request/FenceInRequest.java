package com.online.taxi.dto.map.request;

import lombok.Data;
/**
 * 
 */
@Data
public class FenceInRequest {
	
	private String longitude;
	
	private String latitude;
	
	private String diu;
	
}
