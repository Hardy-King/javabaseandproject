package com.online.taxi.request;

import lombok.Data;

/**
 * @date 2018/8/14
 */
@Data
public class DispatchOrderRequest {
    private Integer orderId;
}
