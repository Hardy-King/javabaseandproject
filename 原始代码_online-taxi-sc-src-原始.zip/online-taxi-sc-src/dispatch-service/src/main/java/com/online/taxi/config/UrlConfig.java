package com.online.taxi.config;

/**
 */
public class UrlConfig {
    public static final String MAP_SERVER_URL = "map";
    public static final String ORDER_SERVER_URL = "order";
    public static final String MESSAGE_SERVER_URL = "message";
}
