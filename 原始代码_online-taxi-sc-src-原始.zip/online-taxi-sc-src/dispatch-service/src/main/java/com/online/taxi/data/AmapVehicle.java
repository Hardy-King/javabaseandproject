package com.online.taxi.data;

import lombok.Data;

/**
 */
@Data
public class AmapVehicle {

    private String vehicleId;

    private String longitude;

    private String latitude;

}
