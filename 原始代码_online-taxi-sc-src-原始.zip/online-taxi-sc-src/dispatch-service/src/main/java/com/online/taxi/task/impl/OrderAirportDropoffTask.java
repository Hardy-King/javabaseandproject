package com.online.taxi.task.impl;

/**
 * @date 2018/10/17
 */
public class OrderAirportDropoffTask extends OrderNormalTask {
    public OrderAirportDropoffTask(int orderId, int type) {
        super(orderId, type);
    }
}
