package com.online.taxi.model;

public interface JsonParser {

    String object2Json(BaseMPRequest baseMPRequest) throws Exception;

}
