package com.online.taxi.constant;

/**
 * @date 2018/10/16
 */
public class MessageAttributeConst {

    public static final String KEY_IPCTYPE = "ipcType";

    public static final String KEY_MESSAGEMAP = "messageMap";
}
