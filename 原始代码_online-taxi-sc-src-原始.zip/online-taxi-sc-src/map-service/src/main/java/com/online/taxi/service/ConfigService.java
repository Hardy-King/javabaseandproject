package com.online.taxi.service;

import com.online.taxi.dto.ResponseResult;

/**
 * @date 2018/10/26
 */
public interface ConfigService {

    ResponseResult getSid();
}
