package com.online.taxi.response;

import lombok.Data;

/**
 * 
 */
@Data
public class AmapFenceInResponse {
	
	private Boolean inFence;
}
