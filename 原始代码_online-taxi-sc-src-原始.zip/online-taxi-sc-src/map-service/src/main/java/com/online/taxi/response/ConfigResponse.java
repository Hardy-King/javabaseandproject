package com.online.taxi.response;

import lombok.Data;

/**
 * @date 2018/10/26
 */
@Data
public class ConfigResponse {

    private String key;

    private String sid;

}
