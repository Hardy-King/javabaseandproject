package com.online.taxi.entity;

import lombok.Data;

/**
 * 
 */
@Data
public class FenceCreateEntity {
	
	private String gid;
	
	private String id;

}
