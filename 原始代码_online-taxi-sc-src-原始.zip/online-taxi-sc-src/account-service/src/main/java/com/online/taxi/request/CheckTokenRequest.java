package com.online.taxi.request;

import lombok.Data;

/**
 *  校验token
 * @date 2018/08/15
 **/
@Data
public class CheckTokenRequest   {

    private String token;
}
