package com.online.taxi.request;

import com.online.taxi.dto.CarBaseInfoView;

import lombok.Data;

/**
 * 车辆信息
 * @date 2018/08/15
 **/
@Data
public class CarInfoRequest {

    private CarBaseInfoView data;
}
