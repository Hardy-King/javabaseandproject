package com.online.taxi.request;

import com.online.taxi.dto.CarBaseInfoView;

import lombok.Data;

/**
 * @date 2018/09/05
 **/
@Data
public class CarChangeRequest   {

    private CarBaseInfoView data;

}
